// node_modules/@ionic/core/components/p-CHqRYvYm.js
var t = class {
  constructor() {
    this.m = /* @__PURE__ */ new Map();
  }
  reset(t5) {
    this.m = new Map(Object.entries(t5));
  }
  get(t5, n3) {
    const e = this.m.get(t5);
    return void 0 !== e ? e : n3;
  }
  getBoolean(t5, n3 = false) {
    const e = this.m.get(t5);
    return void 0 === e ? n3 : "string" == typeof e ? "true" === e : !!e;
  }
  getNumber(t5, n3) {
    const e = parseFloat(this.m.get(t5));
    return isNaN(e) ? void 0 !== n3 ? n3 : NaN : e;
  }
  set(t5, n3) {
    this.m.set(t5, n3);
  }
};
var n = new t();
var c;
!(function(t5) {
  t5.OFF = "OFF", t5.ERROR = "ERROR", t5.WARN = "WARN";
})(c || (c = {}));
var u = (t5, ...e) => {
  const o3 = n.get("logLevel", c.WARN);
  if ([c.WARN].includes(o3)) return console.warn(`[Ionic Warning]: ${t5}`, ...e);
};
var f = (t5, ...e) => {
  const o3 = n.get("logLevel", c.ERROR);
  if ([c.ERROR, c.WARN].includes(o3)) return console.error(`[Ionic Error]: ${t5}`, ...e);
};
var h = ((t5) => (t5.Undefined = "undefined", t5.Null = "null", t5.String = "string", t5.Number = "number", t5.SpecialNumber = "number", t5.Boolean = "boolean", t5.BigInt = "bigint", t5))(h || {});
var p = ((t5) => (t5.Array = "array", t5.Date = "date", t5.Map = "map", t5.Object = "object", t5.RegularExpression = "regexp", t5.Set = "set", t5.Channel = "channel", t5.Symbol = "symbol", t5))(p || {});
var w = (t5) => {
  if (t5.__stencil__getHostRef) return t5.__stencil__getHostRef();
};
var O = (t5, n3) => (0, console.error)(t5, n3);
var M = "undefined" != typeof window ? window : {};
var I = M.HTMLElement || class {
};
var L = { i: 0, u: "", jmp: (t5) => t5(), raf: (t5) => requestAnimationFrame(t5), ael: (t5, n3, e, o3) => t5.addEventListener(n3, e, o3), rel: (t5, n3, e, o3) => t5.removeEventListener(n3, e, o3), ce: (t5, n3) => new CustomEvent(t5, n3) };
var R = (() => {
  var t5;
  let n3 = false;
  try {
    null == (t5 = M.document) || t5.addEventListener("e", null, Object.defineProperty({}, "passive", { get() {
      n3 = true;
    } }));
  } catch (t6) {
  }
  return n3;
})();
var A = (() => {
  try {
    return !!M.document.adoptedStyleSheets && (new CSSStyleSheet(), "function" == typeof new CSSStyleSheet().replaceSync);
  } catch (t5) {
  }
  return false;
})();
var _ = !!A && (() => !!M.document && Object.getOwnPropertyDescriptor(M.document.adoptedStyleSheets, "length").writable)();
var B = false;
var F = [];
var T = [];
var U = (t5, n3) => (e) => {
  t5.push(e), B || (B = true, n3 && 4 & L.i ? V(W) : L.raf(W));
};
var D = (t5) => {
  for (let n3 = 0; n3 < t5.length; n3++) try {
    t5[n3](performance.now());
  } catch (t6) {
    O(t6);
  }
  t5.length = 0;
};
var W = () => {
  D(F), D(T), (B = F.length > 0) && L.raf(W);
};
var V = (t5) => Promise.resolve(void 0).then(t5);
var H = U(F, false);
var P = U(T, true);
var Vt = (t5) => {
  var n3;
  return null == (n3 = w(t5)) ? void 0 : n3.R;
};
var tn = "Capture";
var nn = new RegExp(tn + "$");

// node_modules/@ionic/core/components/p-ZjP4CjeZ.js
var d = "undefined" != typeof window ? window : void 0;
var o = "undefined" != typeof document ? document : void 0;

// node_modules/@ionic/core/components/p-CmR5uXej.js
var t2;
var i = (e, o3, i2) => {
  const n3 = o3.startsWith("animation") ? (r3 = e, void 0 === t2 && (t2 = void 0 === r3.style.animationName && void 0 !== r3.style.webkitAnimationName ? "-webkit-" : ""), t2) : "";
  var r3;
  e.style.setProperty(n3 + o3, i2);
};
var n2 = (e = [], o3) => {
  if (void 0 !== o3) {
    const t5 = Array.isArray(o3) ? o3 : [o3];
    return [...e, ...t5];
  }
  return e;
};
var r = (t5) => {
  let r3, a, s2, d3, l2, f2, c3, v, m2, u2, p2, y = [], g = [], A2 = [], b = false, C = {}, E = [], h2 = [], R2 = {}, S = 0, j = false, k = false, w2 = true, T2 = false, D2 = true, F2 = false;
  const W2 = t5, I3 = [], K = [], M2 = [], P2 = [], Y = [], Z = [], q = [], x = [], H2 = [], z = [], B2 = [], G = "function" == typeof AnimationEffect || void 0 !== d && "function" == typeof d.AnimationEffect, J = "function" == typeof Element && "function" == typeof Element.prototype.animate && G, L2 = () => B2, N = (e, o3) => {
    const t6 = o3.findIndex(((o4) => o4.c === e));
    t6 > -1 && o3.splice(t6, 1);
  }, O2 = (e, o3) => (((null == o3 ? void 0 : o3.oneTimeCallback) ? K : I3).push({ c: e, o: o3 }), p2), Q = () => {
    J && (B2.forEach(((e) => {
      e.cancel();
    })), B2.length = 0);
  }, U2 = () => {
    Z.forEach(((e) => {
      (null == e ? void 0 : e.parentNode) && e.parentNode.removeChild(e);
    })), Z.length = 0;
  }, V2 = () => void 0 !== l2 ? l2 : c3 ? c3.getFill() : "both", X = () => void 0 !== v ? v : void 0 !== f2 ? f2 : c3 ? c3.getDirection() : "normal", $ = () => j ? "linear" : void 0 !== s2 ? s2 : c3 ? c3.getEasing() : "linear", _2 = () => k ? 0 : void 0 !== m2 ? m2 : void 0 !== a ? a : c3 ? c3.getDuration() : 0, ee = () => void 0 !== d3 ? d3 : c3 ? c3.getIterations() : 1, oe = () => void 0 !== u2 ? u2 : void 0 !== r3 ? r3 : c3 ? c3.getDelay() : 0, te = () => {
    0 !== S && (S--, 0 === S && ((() => {
      H2.forEach(((e2) => e2())), z.forEach(((e2) => e2()));
      const e = w2 ? 1 : 0, o3 = E, t6 = h2, n3 = R2;
      P2.forEach(((e2) => {
        const r4 = e2.classList;
        o3.forEach(((e3) => r4.add(e3))), t6.forEach(((e3) => r4.remove(e3)));
        for (const o4 in n3) n3.hasOwnProperty(o4) && i(e2, o4, n3[o4]);
      })), m2 = void 0, v = void 0, u2 = void 0, I3.forEach(((o4) => o4.c(e, p2))), K.forEach(((o4) => o4.c(e, p2))), K.length = 0, D2 = true, w2 && (T2 = true), w2 = true;
    })(), c3 && c3.animationFinish()));
  }, ie = () => {
    (() => {
      q.forEach(((e2) => e2())), x.forEach(((e2) => e2()));
      const e = g, o3 = A2, t6 = C;
      P2.forEach(((n3) => {
        const r4 = n3.classList;
        e.forEach(((e2) => r4.add(e2))), o3.forEach(((e2) => r4.remove(e2)));
        for (const e2 in t6) t6.hasOwnProperty(e2) && i(n3, e2, t6[e2]);
      }));
    })(), y.length > 0 && J && (P2.forEach(((e) => {
      const o3 = e.animate(y, { id: W2, delay: oe(), duration: _2(), easing: $(), iterations: ee(), fill: V2(), direction: X() });
      o3.pause(), B2.push(o3);
    })), B2.length > 0 && (B2[0].onfinish = () => {
      te();
    })), b = true;
  }, ne = (e) => {
    e = Math.min(Math.max(e, 0), 0.9999), J && B2.forEach(((o3) => {
      o3.currentTime = o3.effect.getComputedTiming().delay + _2() * e, o3.pause();
    }));
  }, re = (e) => {
    B2.forEach(((e2) => {
      e2.effect.updateTiming({ delay: oe(), duration: _2(), easing: $(), iterations: ee(), fill: V2(), direction: X() });
    })), void 0 !== e && ne(e);
  }, ae = (e = false, o3 = true, t6) => (e && Y.forEach(((i2) => {
    i2.update(e, o3, t6);
  })), J && re(t6), p2), se = () => {
    b && (J ? B2.forEach(((e) => {
      e.pause();
    })) : P2.forEach(((e) => {
      i(e, "animation-play-state", "paused");
    })), F2 = true);
  }, de = (e) => new Promise(((o3) => {
    (null == e ? void 0 : e.sync) && (k = true, O2((() => k = false), { oneTimeCallback: true })), b || ie(), T2 && (J && (ne(0), re()), T2 = false), D2 && (S = Y.length + 1, D2 = false);
    const t6 = () => {
      N(i2, K), o3();
    }, i2 = () => {
      N(t6, M2), o3();
    };
    O2(i2, { oneTimeCallback: true }), M2.push({ c: t6, o: { oneTimeCallback: true } }), Y.forEach(((e2) => {
      e2.play();
    })), J ? (B2.forEach(((e2) => {
      e2.play();
    })), 0 !== y.length && 0 !== P2.length || te()) : te(), F2 = false;
  })), le = (e, o3) => {
    const t6 = y[0];
    return void 0 === t6 || void 0 !== t6.offset && 0 !== t6.offset ? y = [{ offset: 0, [e]: o3 }, ...y] : t6[e] = o3, p2;
  };
  return p2 = { parentAnimation: c3, elements: P2, childAnimations: Y, id: W2, animationFinish: te, from: le, to: (e, o3) => {
    const t6 = y[y.length - 1];
    return void 0 === t6 || void 0 !== t6.offset && 1 !== t6.offset ? y = [...y, { offset: 1, [e]: o3 }] : t6[e] = o3, p2;
  }, fromTo: (e, o3, t6) => le(e, o3).to(e, t6), parent: (e) => (c3 = e, p2), play: de, pause: () => (Y.forEach(((e) => {
    e.pause();
  })), se(), p2), stop: () => {
    Y.forEach(((e) => {
      e.stop();
    })), b && (Q(), b = false), j = false, k = false, D2 = true, v = void 0, m2 = void 0, u2 = void 0, S = 0, T2 = false, w2 = true, F2 = false, M2.forEach(((e) => e.c(0, p2))), M2.length = 0;
  }, destroy: (e) => (Y.forEach(((o3) => {
    o3.destroy(e);
  })), ((e2) => {
    Q(), e2 && U2();
  })(e), P2.length = 0, Y.length = 0, y.length = 0, I3.length = 0, K.length = 0, b = false, D2 = true, p2), keyframes: (e) => {
    const o3 = y !== e;
    return y = e, o3 && ((e2) => {
      J && L2().forEach(((o4) => {
        const t6 = o4.effect;
        if (t6.setKeyframes) t6.setKeyframes(e2);
        else {
          const i2 = new KeyframeEffect(t6.target, e2, t6.getTiming());
          o4.effect = i2;
        }
      }));
    })(y), p2;
  }, addAnimation: (e) => {
    if (null != e) if (Array.isArray(e)) for (const o3 of e) o3.parent(p2), Y.push(o3);
    else e.parent(p2), Y.push(e);
    return p2;
  }, addElement: (o3) => {
    if (null != o3) if (1 === o3.nodeType) P2.push(o3);
    else if (o3.length >= 0) for (let e = 0; e < o3.length; e++) P2.push(o3[e]);
    else f("createAnimation - Invalid addElement value.");
    return p2;
  }, update: ae, fill: (e) => (l2 = e, ae(true), p2), direction: (e) => (f2 = e, ae(true), p2), iterations: (e) => (d3 = e, ae(true), p2), duration: (e) => (J || 0 !== e || (e = 1), a = e, ae(true), p2), easing: (e) => (s2 = e, ae(true), p2), delay: (e) => (r3 = e, ae(true), p2), getWebAnimations: L2, getKeyframes: () => y, getFill: V2, getDirection: X, getDelay: oe, getIterations: ee, getEasing: $, getDuration: _2, afterAddRead: (e) => (H2.push(e), p2), afterAddWrite: (e) => (z.push(e), p2), afterClearStyles: (e = []) => {
    for (const o3 of e) R2[o3] = "";
    return p2;
  }, afterStyles: (e = {}) => (R2 = e, p2), afterRemoveClass: (e) => (h2 = n2(h2, e), p2), afterAddClass: (e) => (E = n2(E, e), p2), beforeAddRead: (e) => (q.push(e), p2), beforeAddWrite: (e) => (x.push(e), p2), beforeClearStyles: (e = []) => {
    for (const o3 of e) C[o3] = "";
    return p2;
  }, beforeStyles: (e = {}) => (C = e, p2), beforeRemoveClass: (e) => (A2 = n2(A2, e), p2), beforeAddClass: (e) => (g = n2(g, e), p2), onFinish: O2, isRunning: () => 0 !== S && !F2, progressStart: (e = false, o3) => (Y.forEach(((t6) => {
    t6.progressStart(e, o3);
  })), se(), j = e, b || ie(), ae(false, true, o3), p2), progressStep: (e) => (Y.forEach(((o3) => {
    o3.progressStep(e);
  })), ne(e), p2), progressEnd: (e, o3, t6) => (j = false, Y.forEach(((i2) => {
    i2.progressEnd(e, o3, t6);
  })), void 0 !== t6 && (m2 = t6), T2 = false, w2 = true, 0 === e ? (v = "reverse" === X() ? "normal" : "reverse", "reverse" === v && (w2 = false), J ? (ae(), ne(1 - o3)) : (u2 = (1 - o3) * _2() * -1, ae(false, false))) : 1 === e && (J ? (ae(), ne(o3)) : (u2 = o3 * _2() * -1, ae(false, false))), void 0 === e || c3 || de(), p2) };
};

// node_modules/@ionic/core/components/p-C7II1iDj.js
var t3 = (a, i2) => {
  a.componentOnReady ? a.componentOnReady().then(((a2) => i2(a2))) : m((() => i2(a)));
};
var m = (a) => "function" == typeof __zone_symbol__requestAnimationFrame ? __zone_symbol__requestAnimationFrame(a) : "function" == typeof requestAnimationFrame ? requestAnimationFrame(a) : setTimeout(a);

// node_modules/@ionic/core/components/p-BDd9Zrb9.js
var r2 = "ionViewWillEnter";
var t4 = "ionViewDidEnter";
var s = "ionViewWillLeave";
var c2 = "ionViewDidLeave";
var l = "ionViewWillUnload";
var I2 = (n3) => {
  if (n3.classList.contains("ion-page")) return n3;
  return n3.querySelector(":scope > .ion-page, :scope > ion-nav, :scope > ion-tabs") || n3;
};

export {
  n,
  u,
  Vt,
  o,
  r,
  t3 as t,
  r2,
  t4 as t2,
  s,
  c2 as c,
  l,
  I2 as I
};
//# sourceMappingURL=chunk-JF2OLPQA.js.map
